#!/bin/bash
CodeRootDir=`pwd`
LOG_PATH=$CodeRootDir/build-log
REPO_PATH=/EXCHANGE/public/heweimao
REPOSITORY_ADD=ssh://gerrit-cn.motorola.com/partner1/home/repo/dev/platform/android/platform/manifest
function main()
{
    echo "1. revert code"
    echo "2. update code"
    echo "3. only download code"
    read "var_1" "var_2" "var_3"
    echo "input command : $var_1 -- $var_2 -- $var_3"

    check_var $var_1
    res_var=$?
    if [ $res_var = "0" ] ; then
    var_1=""
    fi

    check_var $var_2
    res_var=$?
    if [ $res_var = "0" ] ; then
    var_2=""
    fi

    check_var $var_3
    res_var=$?
    if [ $res_var = "0" ] ; then
    var_3=""
    fi

    echo "valid command : $var_1 -- $var_2 -- $var_3"

    is_exist 1
    res_exist=$?
    if [ $res_exist = "1" ] ; then
        revert_code
    fi

    is_exist 2
    res_exist=$?
    if [ $res_exist = "1" ] ; then
        sleep 3
        sync_code
    fi
    
    is_exist 3
    res_exist=$?
    if [ $res_exist = "1" ] ; then
        if [ ! -d .repo ] ; then
            download_code
        else
            echo "there is already have .repo,cannot download code!!!"
            exit 1
        fi
    fi
    exit 0
}

function revert_code()
{

    echo -e "\033[33mIt's going to revert your code.\033[0m"
    read -n1 -p  "Are you sure? [Y/N]" answer
    case $answer in
        Y | y )
        echo "";;
        *)
	echo -e "\n"
        exit 0 ;;
    esac
    if [ ! -f $REPO_PATH/repo ]; then
        echo "There is not have repo in path:/EXCHANGE/public/heweimao !!!"
        exit 1
    fi
   echo "Start revert Code...."
   echo "repo forall -c \"git clean -df\""
   $REPO_PATH/repo forall -c  "git clean -df"
   echo "repo forall -c \"git co .\""
   $REPO_PATH/repo forall -c "git co ."
   echo "rm -rf $LOG_PATH/*"
   rm -rf $LOG_PATH/*
   echo "rm -rf out"
   rm -rf out    
   echo -e "\033[33mComplete revert code.\033[0m"
   #exit 0
}

function sync_code()
{
    echo -e "\033[33mIt's going to sync your code.\033[0m"
    $REPO_PATH/repo sync -j4
    echo -e "\033[33mComplete sync code.\033[0m"
}

function download_code()
{
    echo "Please select only one branch for download:"
    echo "a. branch mtk/yude/6737_N"
    echo "b. branch mtk/caf/6737_N"
    echo "c. branch mtk/drvonly/6737_N"
    echo "d. branch mtk/yude/6737_7.1"
    echo "e. branch mtk/caf/6737_7.1"
    echo "f. branch mtk/drvonly/6737_7.1"
    read "var_branch"
    echo "input command : $var_branch"
    case $var_branch in
        a) d_command="$REPO_PATH/repo init -u $REPOSITORY_ADD -b mtk/drvonly/6737_N -m yude.xml && $REPO_PATH/repo sync -j4 && $REPO_PATH/repo start mtk/yude/6737_N --all" ;;
        b) d_command="$REPO_PATH/repo init -u $REPOSITORY_ADD -b mtk/caf/6737_N && $REPO_PATH/repo sync -j4 && $REPO_PATH/repo start mtk/caf/6737_N --all" ;;
        c) d_command="$REPO_PATH/repo init -u $REPOSITORY_ADD -b mtk/drvonly/6737_N && $REPO_PATH/repo sync -j4 && $REPO_PATH/repo start mtk/drvonly/6737_N --all" ;;
        d) d_command="$REPO_PATH/repo init -u $REPOSITORY_ADD -b mtk/drvonly/6737_7.1 -m yude.xml && $REPO_PATH/repo sync -j4 && $REPO_PATH/repo start mtk/yude/6737_7.1 --all" ;;
        e) d_command="$REPO_PATH/repo init -u $REPOSITORY_ADD -b mtk/caf/6737_7.1 && $REPO_PATH/repo sync -j4 && $REPO_PATH/repo start mtk/caf/6737_7.1 --all" ;;
        f) d_command="$REPO_PATH/repo init -u $REPOSITORY_ADD -b mtk/drvonly/6737_7.1 && $REPO_PATH/repo sync -j4 && $REPO_PATH/repo start mtk/drvonly/6737_7.1 --all" ;;
        *) d_command="" ;;
    esac
    echo "$d_command"
    if [ x"$d_command" = x ] ; then
        echo "selection error!!!"
        exit 1
    fi
    eval $d_command
}

function is_exist()
{
case $1 in
    $var_1) result=1 ;;
    $var_2) result=1 ;;
    $var_3) result=1 ;;
    $var_4) result=1 ;;
    $var_5) result=1 ;;
    *) result=0 ;;
esac

return $result
}

function check_var()
{
case $1 in
    1) result=1 ;;
    2) result=1 ;;
    3) result=1 ;;
    4) result=1 ;;
    5) result=1 ;;
    6) result=1 ;;
    7) result=1 ;;
    *) result=0 ;;
esac

return $result
}

main $1 $2 $3
