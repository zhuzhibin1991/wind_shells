#!/bin/bash
build_param=$1
release_param=$2

if [ x"$build_param" = "x" ];then
    echo "Usage: command [build_param]. e.g. command l300"
    return 1
fi

if [ x"$release_param" = "x" ];then
   release_param=all
fi

ROOT=`pwd`
OUT_PATH=$ROOT"/out/target/product"
MY_NAME=`whoami`
HARDWARE_VER=S01
PLATFORM=MT6737M

case $build_param in
	lenovo6737m_65_n)
        HARDWARE_VER=S01
        OUT_PATH=$OUT_PATH/lenovo6737m_65_n
        build_param=lenovo6737m_65_n
        PLATFORM=MT6737M
        ;;
	Z168_32B)
        HARDWARE_VER=S01
        OUT_PATH=$OUT_PATH/Z168_32B
        build_param=Z168_32B
        PLATFORM=MT6737M
        ;;
	woods)
        HARDWARE_VER=S01
        OUT_PATH=$OUT_PATH/woods
        build_param=woods
        PLATFORM=MT6737M
        ;;
    *)
        echo "no such project!!"
        exit 1
        ;;
esac

if [ ! -d $OUT_PATH ];then
    echo "ERROR: there is no out path:$OUT_PATH"
    return
fi

if [ x"$release_param" = x"all" ]; then
    for i in "$OUT_PATH/system/vendor/etc/mddb/BPLGUInfoCustomAppSrcP_MT6735_S00_MOLY_LR9*_ltg_n" ; do
        if [ -f $i ]; then
            cp $i  $OUT_PATH/Modem_Database_ltg
        fi
    done
    MODEM_COUNT=(1 2 3 4 5)
    Database_array=()
    for modem_N in ${MODEM_COUNT[*]}; do
        case $modem_N in
            1)
            suffix=EMEA
            #continue
            ;;
            2)
            suffix=LATAM
            #continue
            ;;
            3)
            suffix=ROAP
            #continue
            ;;
            4)
            suffix=LATAM_SKY77638
            #continue
            ;;
            5)
            suffix=ROAP_B28
            #continue
            ;;
        esac
        Database_array[j++]=Modem_Database_lwg_$suffix
        MODEM_FILE=$OUT_PATH/system/vendor/etc/mddb/BPLGUInfoCustomAppSrcP_MT6735_S00_MOLY_LR9*_lwg_$modem_N

        if [ -f $MODEM_FILE ]; then
            cp $MODEM_FILE  $OUT_PATH/Modem_Database_lwg_$suffix
        fi
    done

    for i in "$OUT_PATH/obj/CGEN/APDB_MT6735_"$HARDWARE_VER"_alps-mp-n1.mp1_W17.??" ; do
        if [ -f $i ]; then
            cp $i $OUT_PATH/AP_Database
        fi
    done
    if [ -d $OUT_PATH/trustzone/bin ]; then
    {
        cd $OUT_PATH
        if [ -f ./Z168_SIGN_FILES.zip ]; then
        rm -rf Z168_SIGN_FILES.zip
        fi
	mkdir Z168_SIGN_FILES
	cp -R trustzone/bin/* Z168_SIGN_FILES
	cp obj/PRELOADER_OBJ/bin/preloader_woods_NO_GFH.bin Z168_SIGN_FILES
        zip -rq Z168_SIGN_FILES.zip Z168_SIGN_FILES
	rm -rf Z168_SIGN_FILES
        Z168_SIGN_FILES=Z168_SIGN_FILES.zip
        cd $ROOT
    }
    fi
fi

if [ ! -f $OUT_PATH/Modem_Database_ltg ];then
    ALL_RELEASE_FILES="logo.bin $PLATFORM"_Android_scatter.txt" preloader_$1.bin AP_Database ${Database_array[*]} boot.img secro.img userdata.img system.img lk.bin recovery.img cache.img trustzone.bin $Z168_SIGN_FILES"
    echo $ALL_RELEASE_FILES
elif [ ! -f $OUT_PATH/Modem_Database_lwg ];then
    ALL_RELEASE_FILES="logo.bin $PLATFORM"_Android_scatter.txt" preloader_$1.bin AP_Database Modem_Database_ltg boot.img secro.img userdata.img system.img lk.bin recovery.img cache.img trustzone.bin"
else
    ALL_RELEASE_FILES="logo.bin $PLATFORM"_Android_scatter.txt" preloader_$1.bin AP_Database Modem_Database_ltg Modem_Database_lwg boot.img secro.img userdata.img system.img lk.bin recovery.img cache.img trustzone.bin"
fi

case $release_param in
    all)
        RELEASE_FILES=$ALL_RELEASE_FILES
        ;;
    system)
        RELEASE_FILES="system.img"
        ;;
    recovery)
        RELEASE_FILES="recovery.img"
        ;;
    boot)
        RELEASE_FILES="boot.img"
        ;;
    lk)
        RELEASE_FILES="lk.bin"
        ;;
    logo)
        RELEASE_FILES="logo.bin"
        ;;
    userdata)
        RELEASE_FILES="userdata.img"
        ;;
    pl)
        RELEASE_FILES="preloader_$1.bin"
        ;;
    ota)
        cd $OUT_PATH
        ota_files=`ls -dt full_${build_param}-ota-*.zip | head -n 1`

        if [ -d $OUT_PATH/obj/PACKAGING/target_files_intermediates ]; then
            cd $OUT_PATH/obj/PACKAGING/target_files_intermediates
            target_files=`ls -dt full_${build_param}-target_files-*.zip | head -n 1`
        fi
		
        if [ -f $OUT_PATH/obj/KERNEL_OBJ/vmlinux ]; then
        {
            cd $OUT_PATH/obj/KERNEL_OBJ
            if [ -f ./vmlinux.zip ]; then
            rm -rf vmlinux.zip
            fi
            zip -rq vmlinux.zip vmlinux
            mv $OUT_PATH/obj/KERNEL_OBJ/vmlinux.zip $OUT_PATH
            vmlinux_files=vmlinux.zip
        }
        fi
        if [ -d $OUT_PATH/symbols ]; then
        {
            cd $OUT_PATH
            if [ -f ./symbols.zip ]; then
            rm -rf symbols.zip
            fi
            zip -rq symbols.zip symbols
            symbols_files=symbols.zip
        }
        fi
        cd $ROOT
        
        RELEASE_FILES="$target_files $ota_files $vmlinux_files $symbols_files"
        ;;
    diff)
        if [ -f ./updateA2B.zip ] &&  [ -f ./updateB2C.zip ] ; then
            diff_files="updateA2B.zip updateB2C.zip"
        elif  [ -f ./updateA2B.zip ]; then
            diff_files=updateA2B.zip
        elif  [ -f ./updateB2C.zip ]; then
            diff_files=updateB2C.zip
        fi
        RELEASE_FILES="$diff_files"
        ;;
    none)
        ;;		
    *)
        echo "not supported!!"
        exit 1
        ;;
esac

FILES=""
for file in $RELEASE_FILES; do
    if [ x"$file" == x"system.img" ] ;then
        filesize=`ls -l --block-size=k $OUT_PATH/$file | awk '{print $5}'`
        echo "$file ---- $filesize KB"
    elif [ x"$target_files" != x"" ] && [ x"$file" == x"$target_files" ] ;then
        filesize=`ls -l --block-size=k $OUT_PATH/obj/PACKAGING/target_files_intermediates/$file | awk '{print $5}'`
        echo "$file ---- $filesize KB"    
    elif [ x"$ota_files" != x"" ] && [ x"$file" == x"$ota_files" ] ;then
        filesize=`ls -l --block-size=k $OUT_PATH/$file | awk '{print $5}'`
        echo "$file ---- $filesize KB"
    elif [ x"$vmlinux_files" != x"" ] && [ x"$file" == x"$vmlinux_files" ] ;then
        filesize=`ls -l --block-size=k $OUT_PATH/$file | awk '{print $5}'`
        echo "$file ---- $filesize KB"
    elif [ x"$symbols_files" != x"" ] && [ x"$file" == x"$symbols_files" ] ;then
        filesize=`ls -l --block-size=k $OUT_PATH/$file | awk '{print $5}'`
        echo "$file ---- $filesize KB"
    else
        echo "$file"
    fi
    if [ x"$target_files" != x"" ] && [ x"$file" == x"$target_files" ] ;then
        FILES=$FILES" "$OUT_PATH"/obj/PACKAGING/target_files_intermediates/"$file
    elif [ x"$file" == x"updateA2B.zip" ] || [ x"$file" == x"updateB2C.zip" ] ;then
        FILES=$FILES" "$ROOT"/"$file
    else
        FILES=$FILES" "$OUT_PATH"/"$file
    fi
done

if [ x"$RELEASE_FILES" != x"" ] && [ x"$RELEASE_FILES" != x"$Z168_SIGN_FILES" ]; then
    if [ ! -f "$OUT_PATH/checklist.md5" ]; then
        echo "/*" >> $OUT_PATH/checklist.md5
        echo "* wind-mobi md5sum checklist" >> $OUT_PATH/checklist.md5
        echo "*/" >> $OUT_PATH/checklist.md5
    fi
    for file in $RELEASE_FILES; do
        if [ x"$target_files" != x"" ] && [ x"$file" == x"$target_files" ]; then
            cd $OUT_PATH/obj/PACKAGING/target_files_intermediates
        elif [ x"$file" == x"updateA2B.zip" ] || [ x"$file" == x"updateB2C.zip" ] ;then
            cd $ROOT
        else
            cd $OUT_PATH
        fi
        md5=`md5sum -b $file`
        if [ -f "$OUT_PATH/checklist.md5" ]; then
            if [ x"$target_files" != x"" ] && [ x"$file" == x"$target_files" ] ;then
                line=`grep -n "\-target_files-" $OUT_PATH/checklist.md5 | cut -d ":" -f 1`
            elif [ x"$ota_files" != x"" ] && [ x"$file" == x"$ota_files" ] ;then
                line=`grep -n "\-ota-" $OUT_PATH/checklist.md5 | cut -d ":" -f 1`
            else
                line=`grep -nw "$file" $OUT_PATH/checklist.md5 | cut -d ":" -f 1`
            fi
        fi

        if [ x"$line" != x"" ]; then
            sed -i $line's/.*/'"$md5"'/' $OUT_PATH/checklist.md5
        else
            echo "$md5" >> $OUT_PATH/checklist.md5
        fi
    done
    cd $ROOT
    if [ -f "$OUT_PATH/checklist.md5" ]; then
        FILES=$FILES" "$OUT_PATH"/"checklist.md5
    fi
fi

cp $FILES /data/mine/test/MT6572/$MY_NAME/

echo "Sucess!"
