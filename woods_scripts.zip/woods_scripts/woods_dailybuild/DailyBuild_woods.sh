#!/bin/bash

###############################   �û������趨�� ��ʼ  ############################################
DailyBuildDir=/home2/zhuzhibin/DailyBuild
CodeDir=$DailyBuildDir/Code
DAILYBUILDLOG=$DailyBuildDir/DailyBuild_woods.log
VersionDIR=$DailyBuildDir/Version
Date=$(date +%y%m%d)
###############################   �û������趨�� ����  ############################################








###############################   �ű����������𶯣� ��ʼ  ############################################

LastDate=2000-01-01

function run_script()
{
cd $CodeDir/$FOLDER_NAME
./Auto_build_woods.sh<< EOF
1 2
EOF
echo " start pickup modify details" >> $DAILYBUILDLOG
Copy_files
cd ..
}

function Copy_files(){
    USER=`whoami`
	Date=$(date +%y%m%d)
    cd  $CodeDir/$FOLDER_NAME
    echo "curent pwd in Copy_files is `pwd`" >> $DAILYBUILDLOG
    if [ -f Auto_build_woods.sh ] ;then
      WIND_SW1_IN_VERSION_NUMBER=`grep INNER_VER= ./Auto_build_woods.sh | cut -d "=" -f 2`   
    fi
    if [  $WIND_SW1_IN_VERSION_NUMBER = "" ] ; then
        WIND_SW1_IN_VERSION_NUMBER = $FOLDER_NAME
    fi    
    cd $DailyBuildDir
    if [ ! -d Version ] ;then
      mkdir  Version    
    fi 
     cd Version
    VersionZipName=${WIND_SW1_IN_VERSION_NUMBER}_DBSW1_${Date}
    mkdir $VersionZipName
	Folder_CP_name=$VersionDIR/$VersionZipName
    cd   $Folder_CP_name
    cp -a  $CodeDir/${FOLDER_NAME}/version_package/*   $Folder_CP_name
    echo "cp -a  $CodeDir/${FOLDER_NAME}/version_package/*   $Folder_CP_name"  >> $DAILYBUILDLOG 
	filelist=`ls -a $Folder_CP_name`
	echo "$filelist" >> $DAILYBUILDLOG 
    for filename in $filelist
	do 
	 if [ x"$filename" == x"system-sign.img" ] ;then 
		rm -rf boot.img cache.img lk.bin logo.bin recovery.img secro.img system.img trustzone.bin userdata.img
	 fi
	done
    cd   $VersionDIR
    zip -rq $VersionZipName.zip $VersionZipName
    cp  $VersionZipName.zip  /data/mine/test/MT6572/$USER/$VersionZipName.zip.apk
    echo "cp  $VersionZipName.zip  /data/mine/test/MT6572/$USER/$VersionZipName.zip.apk"   >> $DAILYBUILDLOG 
    cd  $VersionDIR
    rm -rf *
}



function create_product()
{

    cd $CodeDir/
    rm -rf ${FOLDER_NAME}
    mkdir ${FOLDER_NAME}
    cp $DailyBuildDir/Auto_build_woods.sh ./${FOLDER_NAME}/
    run_script
}

function main()
{
  echo "$(date +%Y-%m-%d_%H:%M:%S) begining!!!" >> $DAILYBUILDLOG
  cd  $DailyBuildDir
  export USER=`whoami`
  Project_info=`grep  BUILD_PROJECT= ./Auto_build_woods.sh`
  echo "$Project_info" >>  $DAILYBUILDLOG
  export FOLDER_NAME=${Project_info:14:30}_${Date}
  echo "FOLDER_NAME = $FOLDER_NAME" >>  $DAILYBUILDLOG
  if [ ! -d Code ] ;then
    mkdir  Code
    cd Code
   fi 
   echo "Currentdir is `pwd`" >> $DAILYBUILDLOG
   
   case $1 in
   all)
   echo "start create product " >>$DAILYBUILDLOG
   create_product
   ;;
    *)
	;;
	esac
}

main $1

###############################   �ű����������𶯣� ����  ############################################
