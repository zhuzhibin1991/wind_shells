#!/bin/bash
WsRootDir=`pwd`
MY_NAME=`whoami`
CONFIGPATH=$WsRootDir/device/ginreen
ARM=arm
#KERNELCONFIGPATH=$WsRootDir/kernel-3.18/arch/$ARM/configs
RELEASEPATH=$1
BUILDINFO=$WsRootDir/build-log/buildinfo
ADDGMS=false
RELEASE_PARAM=all
LOG_PATH=$WsRootDir/build-log

#################################### Custom config area ###################################
#version number
INVER=WOODS_Z168_V1.0B22
OUTVER=WOODS_Z168_V1.0
#factory software or not,yes for factory,no for official,official version should have Temperature protection
IS_FACTORY_VERSION=yes
#NEED_SIGNATURE if yes not modify boot key file, if no modify boot key file
NEED_SIGNATURE=no

CPUCORE=16
#################################### Custom config area ###################################

PRODUCT=
VARIANT=
ACTION=
MODULE=
ORIGINAL=
COPYFILES=
CONFIG_NAME=

clean_pl()
{
    if [ x$ORIGINAL == x"yes" ]; then
        rm $LOG_PATH/pl.log; make clean-pl
        return $?
    else
        OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
        PL_OUT_PATH=$OUT_PATH/obj/PRELOADER_OBJ
        rm -f $LOG_PATH/pl.log
        rm -f $OUT_PATH/preloader_$PRODUCT.bin
        rm -rf $PL_OUT_PATH
        result=$?
        return $result
    fi
}
build_pl()
{
    if [ x$ORIGINAL == x"yes" ]; then
        make -j$CPUCORE pl 2>&1 | tee $LOG_PATH/pl.log
        return $?
    else
        OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
        PL_OUT_PATH=$OUT_PATH/obj/PRELOADER_OBJ
        cd vendor/mediatek/proprietary/bootable/bootloader/preloader
        PRELOADER_OUT=$PL_OUT_PATH TARGET_PRODUCT=$PRODUCT ./build.sh 2>&1 | tee $LOG_PATH/pl.log
        result=$?
        cd -
        cp $PL_OUT_PATH/bin/preloader_$PRODUCT.bin $OUT_PATH
        return $result
    fi
}

clean_kernel()
{
    if [ x$ORIGINAL == x"yes" ]; then
        rm $LOG_PATH/k.log; make clean-kernel
        return $?
    else
        OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
        KERNEL_OUT_PATH=$OUT_PATH/obj/KERNEL_OBJ
        rm -f $LOG_PATH/k.log
        rm -f $OUT_PATH/boot.img
        rm -rf $KERNEL_OUT_PATH
        result=$?
        return $result
    fi
}
build_kernel()
{
    if [ x$ORIGINAL == x"yes" ]; then
        make -j$CPUCORE kernel 2>&1 | tee $LOG_PATH/k.log
        return $?
    else
        cd kernel-3.18
        if [ x$VARIANT == x"user" ] || [ x$VARIANT == x"userroot" ];then
            defconfig_files=${PRODUCT}_defconfig
        else
            defconfig_files=${PRODUCT}_debug_defconfig
        fi
        KERNEL_OUT_PATH=../out/target/product/$PRODUCT/obj/KERNEL_OBJ
        mkdir -p $KERNEL_OUT_PATH
        while [ 1 ]; do
            make O=$KERNEL_OUT_PATH ARCH=$ARM ${defconfig_files}
            result=$?; if [ x$result != x"0" ];then break; fi
            #make -j$CPUCORE -k O=$KERNEL_OUT_PATH Image modules
	    if [ x$ARM == x"arm" ];then
            make -j$CPUCORE O=$KERNEL_OUT_PATH ARCH=$ARM CROSS_COMPILE=$WsRootDir/prebuilts/gcc/linux-x86/arm/arm-eabi-4.8/bin/arm-eabi- 2>&1 | tee $LOG_PATH/k.log
            else
	    make -j$CPUCORE O=$KERNEL_OUT_PATH ARCH=$ARM CROSS_COMPILE=$WsRootDir/prebuilts/gcc/linux-x86/aarch64/aarch64-linux-android-4.9/bin/aarch64-linux-android- 2>&1 | tee $LOG_PATH/k.log
	    fi
	    result=$?; if [ x$result != x"0" ];then break; fi
            if [ x$ARM == x"arm" ];then
            cp $KERNEL_OUT_PATH/arch/arm/boot/zImage-dtb ../out/target/product/$PRODUCT/kernel
            else
            cp $KERNEL_OUT_PATH/arch/arm64/boot/Image.gz-dtb ../out/target/product/$PRODUCT/kernel
            fi
            break
        done
        cd -
        return $result
    fi
}

clean_lk()
{
    if [ x$ORIGINAL == x"yes" ]; then
        rm $LOG_PATH/lk.log; make clean-lk
        return $?
    else
        OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
        LK_OUT_PATH=$OUT_PATH/obj/BOOTLOADER_OBJ
        rm -f $LOG_PATH/lk.log
        rm -f $OUT_PATH/lk.bin $OUT_PATH/logo.bin
        rm -rf $LK_OUT_PATH
        result=$?
        return $result
    fi
}
build_lk()
{
    if [ x$ORIGINAL == x"yes" ]; then
        make -j$CPUCORE lk 2>&1 | tee $LOG_PATH/lk.log
        return $?
    else
        OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
        LK_OUT_PATH=$OUT_PATH/obj/BOOTLOADER_OBJ
        mkdir -p $LK_OUT_PATH
        cd vendor/mediatek/proprietary/bootable/bootloader/lk
        export BOOTLOADER_OUT=$LK_OUT_PATH
        export MTK_PUMP_EXPRESS_SUPPORT=yes
        make -j$CPUCORE $PRODUCT 2>&1 | tee $LOG_PATH/lk.log
        result=$?
        cd -
        cp $LK_OUT_PATH/build-$PRODUCT/lk.bin $OUT_PATH
        cp $LK_OUT_PATH/build-$PRODUCT/logo.bin $OUT_PATH
        return $result
    fi
}

revert_code()
{

    echo -e "\033[33mIt's going to revert your code.\033[0m"
    read -n1 -p  "Are you sure? [Y/N]" answer
    case $answer in
        Y | y )
        echo "";;
        *)
	echo -e "\n"
        exit 0 ;;
    esac    
   echo "Start revert Code...."
   echo "repo forall -c \"git clean -df\""
   /EXCHANGE/public/heweimao/repo forall -c  "git clean -df"
   echo "repo forall -c \"git co .\""
   /EXCHANGE/public/heweimao/repo forall -c "git co ."
   echo "rm -rf $LOG_PATH/*"
   rm -rf $LOG_PATH/*
   echo "rm -rf out"
   rm -rf out    
   echo -e "\033[33mComplete revert code.\033[0m"
   exit 0
}

function config_version()
{
    export VER_INNER=$INVER
    export VER_OUTER=$OUTVER
    FTMODULE_PATH=$WsRootDir/vendor/mediatek/proprietary/hardware
    FTMODULE_FILE=`find $FTMODULE_PATH -iname FtModule.cpp`
    if [ -f $FTMODULE_FILE ]; then
         #linenumber=`grep -rni ro.build.display.id $FTMODULE_FILE | cut -d ":" -f 1`
         #sed -i ''$linenumber's/ro.build.display.id/ro.build.wind.version//g' $FTMODULE_FILE
         sed -i '/ro.build.display.id/a\#define RELEASE_BUILD_DISP_ID_TOKEN "ro.build.wind.version"' $FTMODULE_FILE
         sed -i '/ro.build.display.id/d' $FTMODULE_FILE
    else
        echo "FtModule.cpp not found !!!"
        exit 1
    fi
    BUILDINFO_PATH=$WsRootDir/build/tools
    BUILDINFO_FILE=`find $BUILDINFO_PATH -iname buildinfo.sh`
    if [ -f $BUILDINFO_FILE ]; then
        sed -i '/ro.build.wind.version/d' $BUILDINFO_FILE
        sed -i '/ro.build.display.id/d' $BUILDINFO_FILE
        sed -i '/ro.build.version.incremental/a\echo "ro.build.wind.version=Plat:'$VER_INNER'Outer:End"' $BUILDINFO_FILE
        sed -i '/ro.build.version.incremental/a\echo "ro.build.display.id='$VER_OUTER'"' $BUILDINFO_FILE
    else
        echo "buildinfo.sh not found !!!"
        exit 1
    fi
}

function config_temp_protection()
{
    DEBUG_DEFCONFIG=$WsRootDir/kernel-3.18/arch/$ARM/configs/${PRODUCT}_debug_defconfig
    DEFCONFIG=$WsRootDir/kernel-3.18/arch/$ARM/configs/${PRODUCT}_defconfig
    LK_CONFIG=$WsRootDir/vendor/mediatek/proprietary/bootable/bootloader/lk/project/${PRODUCT}.mk
    if [ x$IS_FACTORY_VERSION != x"yes" ] && [ x$IS_FACTORY_VERSION != x"no" ]; then
        echo "IS_FACTORY_VERSION must be yes or no !!!"
        exit 1
    fi
    if [ x$IS_FACTORY_VERSION == x"no" ]; then

        if [ -f $DEBUG_DEFCONFIG ]; then
             sed -i '/CONFIG_WIND_Z168_TEST/d' $DEBUG_DEFCONFIG
        else
            echo "${PRODUCT}_debug_defconfig not found !!!"
            exit 1
        fi
        if [ -f $DEFCONFIG ]; then
             sed -i '/CONFIG_WIND_Z168_TEST/d' $DEFCONFIG
        else
            echo "${PRODUCT}_defconfig not found !!!"
            exit 1
        fi
        if [ -f $LK_CONFIG ]; then
             sed -i '/WIND_Z168_TEST/d' $LK_CONFIG
        else
            echo "${PRODUCT}.mk not found !!!"
            exit 1
        fi
    else
        if [ -f $DEBUG_DEFCONFIG ]; then
             sed -i '/CONFIG_WIND_Z168_TEST/d' $DEBUG_DEFCONFIG
             sed -i '$a CONFIG_WIND_Z168_TEST=y' $DEBUG_DEFCONFIG
        else
            echo "${PRODUCT}_debug_defconfig not found !!!"
            exit 1
        fi
        if [ -f $DEFCONFIG ]; then
             sed -i '/CONFIG_WIND_Z168_TEST/d' $DEFCONFIG
             sed -i '$a CONFIG_WIND_Z168_TEST=y' $DEFCONFIG
        else
            echo "${PRODUCT}_defconfig not found !!!"
            exit 1
        fi
        if [ -f $LK_CONFIG ]; then
             sed -i '/WIND_Z168_TEST/d' $LK_CONFIG
             sed -i '$a WIND_Z168_TEST = yes' $LK_CONFIG
        else
            echo "${PRODUCT}.mk not found !!!"
            exit 1
        fi
    fi

    ##modify WIND_Z168_DEF_YES in woods.mk and modify CONFIG_WIND_Z168_DEF_NO in woods_defconfig && woods_debug_defconfig
    if [ x$IS_FACTORY_VERSION == x"yes" ]; then
        if [ -f $DEBUG_DEFCONFIG ]; then
             sed -i '/CONFIG_WIND_Z168_DEF_NO/d' $DEBUG_DEFCONFIG
             sed -i '$a CONFIG_WIND_Z168_DEF_NO=y' $DEBUG_DEFCONFIG
        else
            echo "${PRODUCT}_debug_defconfig not found !!!"
            exit 1
        fi
        if [ -f $DEFCONFIG ]; then
             sed -i '/CONFIG_WIND_Z168_DEF_NO/d' $DEFCONFIG
             sed -i '$a CONFIG_WIND_Z168_DEF_NO=y' $DEFCONFIG
        else
            echo "${PRODUCT}_defconfig not found !!!"
            exit 1
        fi
        if [ -f $LK_CONFIG ]; then
             sed -i '/WIND_Z168_DEF_YES/d' $LK_CONFIG
             sed -i '$a WIND_Z168_DEF_YES = no' $LK_CONFIG
        else
            echo "${PRODUCT}.mk not found !!!"
            exit 1
        fi
    else
        if [ -f $DEBUG_DEFCONFIG ]; then
             sed -i '/CONFIG_WIND_Z168_DEF_NO/d' $DEBUG_DEFCONFIG
        else
            echo "${PRODUCT}_debug_defconfig not found !!!"
            exit 1
        fi
        if [ -f $DEFCONFIG ]; then
             sed -i '/CONFIG_WIND_Z168_DEF_NO/d' $DEFCONFIG
        else
            echo "${PRODUCT}_defconfig not found !!!"
            exit 1
        fi
        if [ -f $LK_CONFIG ]; then
             sed -i '/WIND_Z168_DEF_YES/d' $LK_CONFIG
             sed -i '$a WIND_Z168_DEF_YES = yes' $LK_CONFIG
        else
            echo "${PRODUCT}.mk not found !!!"
            exit 1
        fi
    fi
}

function config_preloader_time()
{
    PRELOADER_DIR=$WsRootDir/vendor/mediatek/proprietary/bootable/bootloader/preloader/custom/woods
    WOODS_FILE=`find $PRELOADER_DIR -iname woods.mk`
    if [ x$IS_FACTORY_VERSION == x"yes" ]; then
        if [ -f $WOODS_FILE ]; then
            sed -i 's/WIND_PRLOADER_DELAY[ ]*=[ ]*no/WIND_PRLOADER_DELAY=yes/g' $WOODS_FILE
        fi
    else
        if [ -f $WOODS_FILE ]; then
            sed -i 's/WIND_PRLOADER_DELAY[ ]*=[ ]*yes/WIND_PRLOADER_DELAY=no/g' $WOODS_FILE
        fi
    fi
}

function mod_for_cam_parameter()
{
    MIPI_SENSOR_FILE=$WsRootDir/kernel-3.18/drivers/misc/mediatek/imgsensor/src/mt6735m/camera_project/woods/s5k4h8_mipi_raw/s5k4h8mipi_Sensor.c
    MIPI_SENSOR_QT_FILE=$WsRootDir/kernel-3.18/drivers/misc/mediatek/imgsensor/src/mt6735m/camera_project/woods/s5k4h8_mipi_raw_qt/s5k4h8mipi_Sensor_qt.c
    if [ x$IS_FACTORY_VERSION == x"yes" ]; then
        if [ -f $MIPI_SENSOR_FILE ]; then
            sed -i '/af_addr[ ]*=[ ]*.*group[ ]*2/d' $MIPI_SENSOR_FILE
        else
            echo "$MIPI_SENSOR_FILE not found !!!"
            exit 1
        fi
        if [ -f $MIPI_SENSOR_QT_FILE ]; then
            sed -i '/af_addr[ ]*=[ ]*.*group[ ]*2/d' $MIPI_SENSOR_QT_FILE
        else
            echo "$MIPI_SENSOR_QT_FILE not found !!!"
            exit 1
        fi
    fi
}

function del_mmc_rpmb_set_key()
{
    TZ_INIT_FILE=$WsRootDir/vendor/mediatek/proprietary/bootable/bootloader/preloader/platform/mt6735/src/security/trustzone/tz_init.c
    if [ x$IS_FACTORY_VERSION == x"yes" ]; then
        if [ -f $TZ_INIT_FILE ]; then
            sed -i 's/[\/\/]*\(mmc_rpmb_set_key.*\)/\/\/\1/g' $TZ_INIT_FILE
        else
            echo "$TZ_INIT_FILE not found !!!"
            exit 1
        fi
    else
        if [ -f $TZ_INIT_FILE ]; then
            sed -i 's/[\/\/]*\(mmc_rpmb_set_key.*\)/\1/g' $TZ_INIT_FILE
        else
            echo "$TZ_INIT_FILE not found !!!"
            exit 1
        fi
    fi
}

:<<!
function copy_soter_raw()
{
    soter_file=`find ./vendor/mediatek/proprietary/trustzone/ -iname soter.raw`
    if [ ! -f $soter_file ];then
        echo "dest soter.raw not found !!!"
        exit 1
    fi
    soter_file=${soter_file#*/}
    soter_file=${soter_file%/*}
    dest_soter=$WsRootDir/$soter_file/
    SOTER_RAW_PUB=/EXCHANGE/public/woods_z168/soter.raw
    if [ ! -f $SOTER_RAW_PUB ]; then
        echo "The file /EXCHANGE/public/woods_z168/soter.raw does not exist!!!"
        exit 1
    else
        if [ ! -d $WsRootDir/wind_soter ];then
            mkdir -p $WsRootDir/wind_soter
        fi
        cp -f /EXCHANGE/public/woods_z168/soter.raw $WsRootDir/wind_soter
    fi
    SOTER_RAW=$WsRootDir/wind_soter/soter.raw
    if [ ! -f $SOTER_RAW ];then
        echo "The file named soter.raw to replace does not exist,please place soter.raw in wind_soter directory!!!"
        exit 1
    else
        cp -f $SOTER_RAW $dest_soter
    fi
}
!

function copy_fingerprint_libs()
{
    FP_LIBS_SRC_DIR=/EXCHANGE/public/woods_z168/Fp_interrupt/release
    FP_EGISTEC_DIR=$WsRootDir/device/moto/woods/egistec_fp
    TEEI_DIR=$WsRootDir/vendor/mediatek/proprietary/trustzone/microtrust/source/platform/mt6735/teei
    if [ -f $FP_LIBS_SRC_DIR/etsd ] && [ -d $FP_EGISTEC_DIR/bin ];then
        cp -f $FP_LIBS_SRC_DIR/etsd $FP_EGISTEC_DIR/bin
    fi
    if [ -f $FP_LIBS_SRC_DIR/fingerprint.default.so ] && [ -d $FP_EGISTEC_DIR/lib/hw ];then
        cp -f $FP_LIBS_SRC_DIR/fingerprint.default.so $FP_EGISTEC_DIR/lib/hw
    fi
    if [ -f $FP_LIBS_SRC_DIR/libEtsdc.so ] && [ -d $FP_EGISTEC_DIR/lib ];then
        cp -f $FP_LIBS_SRC_DIR/libEtsdc.so $FP_EGISTEC_DIR/lib
    fi
    if [ -f $FP_LIBS_SRC_DIR/libFpEts.so ] && [ -d $FP_EGISTEC_DIR/lib ];then
        cp -f $FP_LIBS_SRC_DIR/libFpEts.so $FP_EGISTEC_DIR/lib
    fi
    if [ -f $FP_LIBS_SRC_DIR/signfp_server ] && [ -d $TEEI_DIR ];then
        cp -f $FP_LIBS_SRC_DIR/signfp_server $TEEI_DIR/fp_server
    fi
}

function rm_file_for_mic()
{
    MIC_FILE=$WsRootDir/vendor/mediatek/proprietary/custom/woods/cgen/cfgdefault/sph_coeff_record_mode_default.h
    if [ -f $MIC_FILE ];then
        rm -rf $MIC_FILE
    fi
}

#zhangheting@wind-mobi.com add sign modify 20170220 start
function modify_sign_key()
{
    LK_DIR=$WsRootDir/vendor/mediatek/proprietary/bootable/bootloader/lk/target/woods
    PRELOADER_DIR=$WsRootDir/vendor/mediatek/proprietary/bootable/bootloader/preloader/custom/woods
    OEMKEY_FILE=`find $LK_DIR -iname oemkey.h`
    CUST_SEC_CTRL_FILE=`find $PRELOADER_DIR -iname cust_sec_ctrl.h`
    WOODS_FILE=`find $PRELOADER_DIR -iname woods.mk`
    PRO_CONF_FILE=$WsRootDir/device/moto/woods/ProjectConfig.mk

    if [ x$NEED_SIGNATURE == x"yes" ];then
        if [ -f $WOODS_FILE ]; then
           sed -i 's/'"MTK_SEC_BOOT[ ]*=[ ]*ATTR_SBOOT_ONLY_ENABLE_ON_SCHIP"'/'"MTK_SEC_BOOT=ATTR_SBOOT_ENABLE"'/g' $WOODS_FILE
           sed -i 's/'"MTK_SEC_USBDL[ ]*=[ ]*ATTR_SUSBDL_ONLY_ENABLE_ON_SCHIP"'/'"MTK_SEC_USBDL=ATTR_SUSBDL_ENABLE"'/g' $WOODS_FILE
           sed -i 's/MTK_SEC_SECRO_AC_SUPPORT[ ]*=[ ]*yes/MTK_SEC_SECRO_AC_SUPPORT=no/g' $WOODS_FILE
        fi
        if [ -f $PRO_CONF_FILE ]; then
            sed -i 's/MTK_SEC_SECRO_AC_SUPPORT[ ]*=[ ]*yes/MTK_SEC_SECRO_AC_SUPPORT = no/g' $PRO_CONF_FILE
        fi
########################## File restore ##########################################        
        if [ -f $OEMKEY_FILE ]; then
            sed -i 's/^[ ]*#if[ ]*[0-1][ ]*/#if 0/g' $OEMKEY_FILE
        fi

        if [ -f $CUST_SEC_CTRL_FILE ]; then
            sed -i 's/^[ ]*#if[ ]*[0-1][ ]*/#if 0/g' $CUST_SEC_CTRL_FILE
        fi
########################## File restore ##########################################

    else
        if [ -f $OEMKEY_FILE ]; then
            sed -i 's/^[ ]*#if[ ]*[0-1][ ]*/#if 1/g' $OEMKEY_FILE
        fi

        if [ -f $CUST_SEC_CTRL_FILE ]; then
            sed -i 's/^[ ]*#if[ ]*[0-1][ ]*/#if 1/g' $CUST_SEC_CTRL_FILE
        fi
######################################### File restore ################################################################################       
        if [ -f $WOODS_FILE ]; then
           sed -i 's/'"MTK_SEC_BOOT[ ]*=[ ]*ATTR_SBOOT_ENABLE"'/'"MTK_SEC_BOOT=ATTR_SBOOT_ONLY_ENABLE_ON_SCHIP"'/g' $WOODS_FILE
           sed -i 's/'"MTK_SEC_USBDL[ ]*=[ ]*ATTR_SUSBDL_ENABLE"'/'"MTK_SEC_USBDL=ATTR_SUSBDL_ONLY_ENABLE_ON_SCHIP"'/g' $WOODS_FILE
           sed -i 's/MTK_SEC_SECRO_AC_SUPPORT[ ]*=[ ]*no/MTK_SEC_SECRO_AC_SUPPORT=yes/g' $WOODS_FILE
        fi
        if [ -f $PRO_CONF_FILE ]; then
            sed -i 's/MTK_SEC_SECRO_AC_SUPPORT[ ]*=[ ]*no/MTK_SEC_SECRO_AC_SUPPORT = yes/g' $PRO_CONF_FILE
        fi
######################################### File restore ################################################################################
    fi
}
#zhangheting@wind-mobi.com add sign modify 20170220 end

function main()
{
    ##################################################################
    #Check parameters
    ##################################################################
    if [ ! -d $LOG_PATH ];then
        mkdir $LOG_PATH
    fi

    command_array=()
    i=0
    command_flag=0
    compare_array=($1 $2 $3 $4 $5)
    if [ -f $BUILDINFO ]; then
        while read line
        do
            command_array[i++]=$line
        done < $BUILDINFO
        #echo ${#command_array[@]}

        for command in ${command_array[*]}; do
            for compare in ${compare_array[*]}; do
                if [ x$command == x$compare ];then 
                    command_flag=1
                    break
                fi
            done

                if [ x$command_flag == x"0" ];then
                    echo "build command is no equal and build command is null !!!"
                    break 
                else
                    command_flag=0
                fi
        done
    fi

    if [[ x$command_flag == x"0" ]] && [[ x$1 != x"" ]];then
        command_array=($1 $2 $3 $4 $5)
    fi

    rm -f $BUILDINFO

    for command in ${command_array[*]}; do

        echo $command >> $BUILDINFO
        ### set PRODUCT
        case $command in
            lenovo6737m_35_n)
            if [ x$PRODUCT != x"" ];then continue; fi
            PRODUCT=lenovo6737m_35_n
            RELEASEPATH=lenovo6737m_35_n
            ADDGMS=false
            CONFIG_NAME=$command
            ORIGINAL=yes
            continue
            ;;
            woods)
            if [ x$PRODUCT != x"" ];then continue; fi
            PRODUCT=woods
            RELEASEPATH=woods
            ADDGMS=false
            ARM=arm
            CONFIG_NAME=$command
            ORIGINAL=yes
            continue
            ;;
        esac

        ### set VARIANT
        if [ x$command == x"user" ] ;then
            if [ x$VARIANT != x"" ];then continue; fi
            VARIANT=user
        elif [ x$command == x"debug" ] ;then
            if [ x$VARIANT != x"" ];then continue; fi
            VARIANT=userdebug
        elif [ x$command == x"eng" ] ;then
            if [ x$VARIANT != x"" ];then continue; fi
            VARIANT=eng
        elif [ x$command == x"userroot" ] ;then
            if [ x$VARIANT != x"" ];then continue; fi
            VARIANT=userroot
        ### set ACTION
        elif [ x$command == x"r" ] || [ x$command == x"remake" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=remake
        elif [ x$command == x"n" ] || [ x$command == x"new" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=new
        elif [ x$command == x"c" ] || [ x$command == x"clean" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=clean
            RELEASE_PARAM=none
        elif [ x$command == x"revert" ] ;then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=revert
            RELEASE_PARAM=none
        elif [ x$command == x"mmma" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=mmma
            RELEASE_PARAM=none
        elif [ x$command == x"mmm" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=mmm
            RELEASE_PARAM=none
        elif [ x$command == x"api" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=update-api
            RELEASE_PARAM=none
        elif [ x$command == x"boot" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=bootimage
            RELEASE_PARAM=boot
        elif [ x$command == x"system" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=systemimage
            RELEASE_PARAM=system
        elif [ x$command == x"userdata" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=userdataimage
            RELEASE_PARAM=userdata
        elif [ x$command == x"boot-nodeps" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=bootimage-nodeps
            RELEASE_PARAM=boot
        elif [ x$command == x"snod" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=snod
            RELEASE_PARAM=system
        elif [ x$command == x"userdata-nodeps" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=userdataimage-nodeps
            RELEASE_PARAM=userdata
        elif [ x$command == x"ramdisk-nodeps" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=ramdisk-nodeps
            RELEASE_PARAM=boot
        elif [ x$command == x"cache" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=cacheimage
            RELEASE_PARAM=none
        elif [ x$command == x"otapackage" ] || [ x$command == x"ota" ] ;then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=otapackage
            RELEASE_PARAM=ota
        elif [ x$command == x"otadiff" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=otadiff
            RELEASE_PARAM=none
        elif [ x$command == x"cts" ];then
            if [ x$ACTION != x"" ];then continue; fi
            ACTION=cts
            RELEASE_PARAM=none

        ### set ORIGINAL
        elif [ x$command == x"o" ];then
            if [ x$ORIGINAL != x"" ];then continue; fi
            ORIGINAL=yes

        ### set COPYFILES
        elif [ x$command == x"nc" ];then
            if [ x$COPYFILES != x"" ];then continue; fi
            COPYFILES=no


        ### set ADDGMS
        elif [ x$command == x"ng" ];then
            if [ x$ADDGMS == x"false" ];then continue; fi
            ADDGMS=false

        ### set MODULE
        elif [ x$command == x"pl" ];then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=pl
            RELEASE_PARAM=pl
        elif [ x$command == x"k" ] || [ x$command == x"kernel" ];then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=k
            RELEASE_PARAM=boot
        elif [ x$command == x"lk" ];then
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=lk
            RELEASE_PARAM=lk
        #elif [ x$command == x"dr" ];then
            #if [ x$MODULE != x"" ];then continue; fi
            #MODULE=dr
            #RELEASE_PARAM=system
        else
            if [ x$MODULE != x"" ];then continue; fi
            MODULE=$command
        fi
    done

    if [ x$VARIANT == x"" ];then VARIANT=eng; fi
    if [ x$ORIGINAL == x"" ];then ORIGINAL=no; fi
    if [ x$ACTION == x"clean" ];then RELEASE_PARAM=none; fi
    #if [ x$COPYFILES == x"" ];then
    #    if [ x$ACTION == x"new" ] && [ x$MODULE == x"" ];then
    #        COPYFILES=yes;
    #    else
    #        COPYFILES=no;
    #    fi
    #fi
    if [ x$ACTION == x"revert" ];then
        revert_code
    fi

    ### Check VARIANT WHEN NOT NEW
    Check_Variant

    echo "********This build project CONFIG_NAME is $CONFIG_NAME********"
    echo "PRODUCT=$PRODUCT VARIANT=$VARIANT ACTION=$ACTION MODULE=$MODULE ORIGINAL=$ORIGINAL"
    echo "Log Path $LOG_PATH"

    if [ x$PRODUCT == x"" ];then
        echo  -e "\033[31m !!!!!!   No Such Product   !!!! \033[0m"
        exit 1
    fi
    if [ x$ACTION == x"" ];then
        echo  -e "\033[31m !!!!!!   No Such Action   !!!! \033[0m"
        exit 1
    fi

    if [ x$IS_FACTORY_VERSION == x"yes" ];then
        export WIND_DEF_WOODS_BR=yes
        export WIND_DEF_WOODS_FACTORY=yes
    else
        export WIND_DEF_WOODS_BR=no
        export WIND_DEF_WOODS_FACTORY=no
    fi

    ##################################################################
    #Prepare
    ##################################################################
    Check_Space
    config_version
    config_temp_protection
    config_preloader_time
    mod_for_cam_parameter
    del_mmc_rpmb_set_key
    #zhangheting@wind-mobi.com add sign modify 20170220 start
    modify_sign_key
    #zhangheting@wind-mobi.com add sign modify 20170220 end
    #copy_soter_raw
    ##Fingerprint interrupt test, but do not want to submit to the Lenovo git repository
    copy_fingerprint_libs
    rm_file_for_mic

    ##################################################################
    #Add GMS
    ##################################################################
    if [ x"$ADDGMS" == x"true" ];then
        if [ x$ACTION == x"remake" ] || [ x$ACTION == x"new" ];then
            if [ x$MODULE == x"" ];then
                addGMS
            fi
        fi
    fi

    ###################################################################
    #Start build
    ###################################################################
    echo "Build started `date +%Y%m%d_%H%M%S` ..."
    echo;echo;echo;echo

    source build/envsetup.sh
    if [ x$VARIANT == x"userroot" ] ; then
        #lunch full_$PRODUCT-user
        lunch $PRODUCT-user
    else    
        #lunch full_$PRODUCT-$VARIANT
        lunch $PRODUCT-$VARIANT
    fi    
    ##source mbldenv.sh
    ##source ./change_java.sh 1.7
    OUT_PATH=$WsRootDir/out/target/product/$PRODUCT
    case $ACTION in
        new | remake | clean)

        M=false; C=false;
        if [ x$ACTION == x"new" ];then M=true; C=true;
        elif [ x$ACTION == x"remake" ];then
          M=true;
          find $OUT_PATH/ -name 'build.prop' -exec rm -rf {} \;
        else C=true;
        fi

        case $MODULE in
            pl)
            if [ x$C == x"true" ];then clean_pl; result=$?; fi
            if [ x$M == x"true" ];then build_pl; result=$?; fi
            ;;

            k)
            if [ x$C == x"true" ];then clean_kernel; result=$?; fi
            if [ x$M == x"true" ];then
                build_kernel; result=$?
                if [ $result -eq 0 ];then make -j$CPUCORE bootimage-nodeps; result=$?; fi
            fi
            ;;

            lk)
            if [ x$C == x"true" ];then clean_lk; result=$?; fi
            if [ x$M == x"true" ];then build_lk; result=$?; fi
            ;;

            *)
            if [ x"$MODULE" == x"" ];then
                if [ x$C == x"true" ];then make clean; rm $LOG_PATH; fi
                if [ x$M == x"true" ];then 
                    if [ x$VARIANT == x"userroot" ] ; then
                        echo "make userroot version"
                        make MTK_BUILD_ROOT=yes -j$CPUCORE 2>&1 | tee $LOG_PATH/build.log; result=$?; 
                    else
                        make -j$CPUCORE 2>&1 | tee $LOG_PATH/build.log; result=$?; 
                    fi
                fi
            else
                echo  -e "\033[31m !!!!!!   No Such module   !!!! \033[0m"
                exit 1
            fi
            ;;
        esac
        ;;
                
        mmma | mmm)
        $ACTION $MODULE 2>&1 | tee $LOG_PATH/$ACTION.log; result=$?
        ;;
        
        update-api | bootimage | systemimage | userdataimage | cacheimage | snod | bootimage-nodeps | userdataimage-nodeps | ramdisk-nodeps | otapackage | otadiff | cts)
        make -j$CPUCORE $ACTION 2>&1 | tee $LOG_PATH/$ACTION.log; result=$?
        ;;
    esac

    if [ $result -eq 0 ] && [ x$ACTION == x"mmma" -o x$ACTION == x"mmm" ];then
        echo "Start to release module ...."
        DIR=`echo $MODULE | sed -e 's/:.*//' -e 's:/$::'`   #ȥ������ģ��·������б��"/"
        NAME=${DIR##*/}             #ȡ��ģ����
        TARGET=out/target/product/${PRODUCT}/obj/APPS/${NAME}_intermediates/package.apk
        if [ -f $TARGET ];then
            cp -f $TARGET /data/mine/test/MT6572/${MY_NAME}/${NAME}.apk
        fi
    elif [ $result -eq 0 ] && [ $RELEASE_PARAM != "none" ]; then
        echo "Build completed `date +%Y%m%d_%H%M%S` ..."
        echo "Start to release version ...."
        ./release_version.sh ${RELEASEPATH} ${RELEASE_PARAM}
    fi
	cd prebuilts/sdk/tools
	./jack-admin kill-server
	cd -

}

function addGMS()
{
    GMS=$WsRootDir/../GMS_6.0_MT6753/gms-oem-mnc-6.0.1-signed-r5-20160608/google

    if [ -d $GMS ];then
        echo "Remove old GMS"
        rm -fr vendor/google
        echo "Start to copy new GMS" 
        cp -a $GMS vendor/
        echo "Complete copy new GMS"
    fi
}

function Check_Space()
{
    UserHome=`pwd`
    Space=0
    Temp=`echo ${UserHome#*/}`
    Temp=`echo ${Temp%%/*}`
    ServerSpace=`df -lh $UserHome | grep "$Temp" | awk '{print $4}'`

    if echo $ServerSpace | grep -q 'G'; then
        Space=`echo ${ServerSpace%%G*}`
    elif echo $ServerSpace | grep -q 'T';then
        TSpace=1
    fi

    echo -e "\033[34m Log for Space $UserHome $ServerSpace $Space !!!\033[0m"
    if [ x"$TSpace" != x"1" ] ;then
        if [ "$Space" -le "30" ];then
            echo -e "\033[31m No Space!! Please Check!! \033[0m"
            exit 1
        fi  
    fi
}

function Check_Variant()
{
    buildProp=$WsRootDir/out/target/product/$PRODUCT/system/build.prop
    if [ -f $buildProp ] ; then
        buildType=`grep  ro.build.type $buildProp | cut -d "=" -f 2`
        if [ x$buildType != x"user" ] && [ x$buildType != x"userdebug" ]  && [ x$buildType != x"eng" ] ; then return; fi
        if [ x$VARIANT != x$buildType ]; then
            if [ x$ACTION == x"new" ]  ; then
                if [ x$MODULE == x"k" ] || [ x$MODULE == x"pl" ] || [ x$MODULE == x"lk" ] ; then
                    echo -e "\033[35mCode build type is\033[0m \033[31m$buildType\033[35m, your input type is\033[0m \033[31m$VARIANT\033[0m"
                    echo -e "\033[35mIf not correct, Please enter \033[31mCtrl+C\033[35m to Stop!!!\033[0m"
                    for i in $(seq 9|tac); do
                        echo -e "\033[34m\aLeft seconds:(${i})\033[0m"
                        sleep 1
                    done
                    echo
                fi
            else
                echo -e "\033[35mCode build type is\033[0m \033[31m$buildType\033[35m, your input type is\033[0m \033[31m$VARIANT\033[0m"
                echo -e "\033[35mChange build type to \033[31m$buildType\033[0m"
                echo
                VARIANT=$buildType
            fi
        fi
    else
        return;
    fi
}

main $1 $2 $3 $4 $5

